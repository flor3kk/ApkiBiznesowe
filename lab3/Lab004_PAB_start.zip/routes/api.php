<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HotelController;

Route::apiResource('hotels', HotelController::class);

# https://laravel.com/docs/11.x/controllers#restful-nested-resources
